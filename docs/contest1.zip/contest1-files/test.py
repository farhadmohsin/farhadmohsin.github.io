#!/usr/bin/env python3
import os, sys, subprocess, tempfile

TIMEOUT = 2  # seconds per test case
HERE = os.path.dirname(os.path.abspath(__file__))

if len(sys.argv) != 3:
    sys.exit("usage: ./test.py <problem> <file>   e.g. ./test.py A sol.cpp")
prob, src = sys.argv[1].upper(), os.path.abspath(sys.argv[2])
casedir = os.path.join(HERE, "testCases", prob)
if not os.path.isdir(casedir):
    sys.exit(f"no test cases for problem {prob}")
if not os.path.isfile(src):
    sys.exit(f"file not found: {sys.argv[2]}")

tmp = tempfile.mkdtemp()
stem, ext = os.path.splitext(os.path.basename(src))
if ext in (".cpp", ".cc"):
    build, run = ["g++", "-O2", "-std=c++17", "-o", f"{tmp}/a.out", src], [f"{tmp}/a.out"]
elif ext == ".py":
    build, run = None, ["python3", src]
elif ext == ".java":
    build, run = ["javac", "-d", tmp, src], ["java", "-cp", tmp, stem]
else:
    sys.exit(f"unsupported file type: {ext}  (use .cpp, .py, or .java)")

if build:
    r = subprocess.run(build, capture_output=True, text=True)
    if r.returncode:
        sys.exit("Compilation failed:\n" + r.stderr)

def norm(s):
    return "\n".join(l.rstrip() for l in s.rstrip().splitlines())

cases = sorted((f[:-3] for f in os.listdir(casedir) if f.endswith(".in")),
               key=lambda s: (len(s), s))
passed, first_fail = 0, None
for c in cases:
    inp = open(os.path.join(casedir, c + ".in")).read()
    exp = open(os.path.join(casedir, c + ".out")).read()
    try:
        r = subprocess.run(run, input=inp, capture_output=True, text=True, timeout=TIMEOUT)
        if r.returncode:
            verdict, yours = "Runtime Error", r.stderr
        elif norm(r.stdout) == norm(exp):
            verdict = "PASS"
        else:
            verdict, yours = "Wrong Answer", r.stdout
    except subprocess.TimeoutExpired:
        verdict, yours = "Time Limit Exceeded", f"(no result within {TIMEOUT}s)"
    print(f"Test {c}: {verdict}")
    if verdict == "PASS":
        passed += 1
    elif first_fail is None:
        first_fail = (c, verdict, inp, exp, yours)

print(f"\nPassed {passed}/{len(cases)}")
if first_fail:
    c, verdict, inp, exp, yours = first_fail
    print(f"\nFirst failure: test {c} ({verdict})")
    print("--- Input ---\n" + inp.rstrip())
    print("--- Expected ---\n" + exp.rstrip())
    print("--- Yours ---\n" + yours.rstrip())
